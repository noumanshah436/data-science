"""
NumPy: meshgrid

- np.meshgrid(x, y) generates coordinate matrices for a grid.
- Useful in plotting surfaces.

Example 1: Creating a grid from x=[1,2,3], y=[4,5]
"""

import numpy as np

x = np.array([1,2,3])
y = np.array([4,5])

X, Y = np.meshgrid(x, y)
print("X Grid:\n", X)
print("Y Grid:\n", Y)
