"""
NumPy: vstack

- np.vstack((a, b)) stacks arrays vertically (row-wise).

Example 1: Stack two 1D arrays
"""

import numpy as np

a = np.array([1,2,3])
b = np.array([4,5,6])

stacked = np.vstack((a, b))
print("Stacked vertically:\n", stacked)
